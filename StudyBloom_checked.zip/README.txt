StudyBloom
A small, friendly study website for students.

Files:
- index.html
- style.css
- script.js

The timer, task planner, tips, challenge and emergency study planner are interactive.
Upload all three website files to your GitHub repository, then enable GitHub Pages.
